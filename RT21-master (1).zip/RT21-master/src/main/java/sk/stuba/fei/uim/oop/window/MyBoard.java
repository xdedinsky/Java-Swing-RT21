package sk.stuba.fei.uim.oop.window;

import lombok.Getter;
import lombok.Setter;
import sk.stuba.fei.uim.oop.components.Tree;
import sk.stuba.fei.uim.oop.logic.MouseLogic;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class MyBoard extends JPanel {
    @Getter@Setter
    private MyMenu menu;
    @Getter@Setter
    ArrayList<Tree> trees;
    public MyBoard(MyMenu menu) {
        this.setVisible(true);
        this.setOpaque(true);
        this.trees = new ArrayList<>();
        this.menu = menu;
        MouseLogic mouseLogic = new MouseLogic(menu,this);
        this.addMouseListener(mouseLogic);
        this.addMouseMotionListener(mouseLogic);
    }


    @Override
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        for (Tree tree : trees) {
            tree.paint(g);
            this.revalidate();
            this.repaint();
        }
    }
}

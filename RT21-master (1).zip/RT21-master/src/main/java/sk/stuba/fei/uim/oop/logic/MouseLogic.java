package sk.stuba.fei.uim.oop.logic;

import sk.stuba.fei.uim.oop.components.Tree;
import sk.stuba.fei.uim.oop.window.MyBoard;
import sk.stuba.fei.uim.oop.window.MyMenu;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

public class MouseLogic implements MouseListener, MouseMotionListener {
    private MyMenu menu;
    private MyBoard board;
    private Tree currentTree;
    private int diffX;
    private int diffY;

    public MouseLogic(MyMenu menu, MyBoard board) {
        this.menu = menu;
        this.board = board;
    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {
        if (menu.getMode() == 0) {
            currentTree = new Tree(e.getX(), e.getY(), menu.getColors().get(menu.getColorIndex()));
            board.getTrees().add(currentTree);
            board.paintComponent(board.getGraphics());
        }
        if (menu.getMode() == 1) {
            diffX = 0;
            diffY = 0;
            for (Tree tree : board.getTrees()) {
                if (tree.isClicked(e.getX(), e.getY())) {
                    currentTree = tree;
                    diffX = e.getX() - tree.getX();
                    diffY = e.getY() - tree.getY();
                    return;
                }
            }
            currentTree = null;
        }
    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void mouseDragged(MouseEvent e) {
        if (menu.getMode() == 0) {
                currentTree.setXEnd(e.getX() - currentTree.getX());
                currentTree.setYEnd(e.getY() - currentTree.getY());
                board.paintComponent(board.getGraphics());
        }
        if (menu.getMode() == 1) {
            if (currentTree != null) {
                currentTree.setX(e.getX() - diffX);
                currentTree.setY(e.getY() - diffY);
                board.paintComponent(board.getGraphics());
            }
        }
    }


    @Override
    public void mouseMoved(MouseEvent e) {

    }
}

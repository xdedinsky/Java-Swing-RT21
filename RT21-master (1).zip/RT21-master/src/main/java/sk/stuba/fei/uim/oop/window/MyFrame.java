package sk.stuba.fei.uim.oop.window;

import javax.swing.*;
import java.awt.*;

public class MyFrame {
    public MyFrame() {
        JFrame frame = new JFrame("ExamRT");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 800);
        frame.setResizable(false);
        frame.setVisible(true);

        MyMenu menu = new MyMenu();
        frame.add(menu, BorderLayout.SOUTH);
        MyBoard board = new MyBoard(menu);
        frame.add(board, BorderLayout.CENTER);

        frame.revalidate();
        frame.repaint();
    }
}

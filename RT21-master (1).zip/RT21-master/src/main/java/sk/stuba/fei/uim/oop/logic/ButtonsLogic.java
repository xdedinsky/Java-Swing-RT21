package sk.stuba.fei.uim.oop.logic;

import sk.stuba.fei.uim.oop.window.MyMenu;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ButtonsLogic implements ActionListener {
    MyMenu menu;
    public ButtonsLogic(MyMenu menu) {
        this.menu = menu;
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        switch(e.getActionCommand()) {
            case "Tree":
                menu.setMode(0);
                break;
            case "Move":
                menu.setMode(1);
                break;
            case "Color":
                menu.setColorIndex((menu.getColorIndex() + 1) % menu.getColors().size());
                menu.getColorPanel().setBackground(menu.getColors().get(menu.getColorIndex()));
                menu.setBackground(menu.getColors().get(menu.getColorIndex()));
                break;
        }
    }
}

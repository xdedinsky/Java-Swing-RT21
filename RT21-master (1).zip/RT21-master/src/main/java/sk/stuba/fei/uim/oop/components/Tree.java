package sk.stuba.fei.uim.oop.components;

import lombok.Getter;
import lombok.Setter;

import java.awt.*;

@Getter @Setter
public class Tree {
    private int x;
    private int y;
    private int xEnd;
    private int yEnd;
    private Color color;

    public Tree(int x, int y, Color color) {
        this.x = x;
        this.y = y;
        this.xEnd = 0;
        this.yEnd = 0;
        this.color = color;
    }

    public void paint(Graphics g){
        g.setColor(color);
        int x1=x,y1=y,x2=xEnd,y2=yEnd;
        if (xEnd < 0){
            x1 = x + xEnd;
            x2 = -xEnd;
        }
        if (yEnd < 0){
            y1 = y + yEnd;
            y2 = -yEnd;
        }
        g.fillOval(x1,y1,x2,(y2*2)/3);
        g.fillRect(x1 + x2/3,y1 + y2/3, x2/3,2*y2/3);
    }

    public boolean isClicked(int x, int y) {
        return x >= this.x && x <= this.x + this.xEnd && y >= this.y && y <= this.y + this.yEnd;
    }
}

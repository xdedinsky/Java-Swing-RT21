package sk.stuba.fei.uim.oop.window;

import lombok.Getter;
import lombok.Setter;
import sk.stuba.fei.uim.oop.logic.ButtonsLogic;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class MyMenu extends JPanel {
    private static final String TREE_BUTTON = "Tree";
    private static final String MOVE_BUTTON = "Move";
    private static final String COLOR_BUTTON = "Color";
    @Getter @Setter
    private JPanel colorPanel;
    @Getter
    private ArrayList<Color> colors;
    @Getter @Setter
    private int colorIndex;
    @Getter @Setter
    private int mode;
    public MyMenu() {

        colorPanel = new JPanel();
        colors = new ArrayList<>();
        colors.add(Color.RED);
        colors.add(Color.BLUE);
        colors.add(Color.GREEN);
        colors.add(Color.YELLOW);

        mode = 0;
        colorIndex = 0;
        this.setBackground(colors.get(colorIndex));
        ButtonsLogic buttonsLogic = new ButtonsLogic(this);

        JButton treeButton = new JButton(TREE_BUTTON);
        treeButton.addActionListener(buttonsLogic);
        JButton moveButton = new JButton(MOVE_BUTTON);
        moveButton.addActionListener(buttonsLogic);
        JButton colorButton = new JButton(COLOR_BUTTON);
        colorButton.addActionListener(buttonsLogic);
        colorPanel.setBackground(Color.RED);

        this.setLayout(new GridLayout(1,4));
        add(treeButton);
        add(moveButton);
        add(colorButton);
        add(colorPanel);

    }
}
